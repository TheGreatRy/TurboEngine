#!/usr/bin/env bash

# Copies documentation to blog
cp -R build/docs/html/. ../box2d_blog/public/documentation/
