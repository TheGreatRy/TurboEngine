Make sure these boxes are checked before submitting your issue - thank you!

- [ ] Ask for help on [discord](https://discord.gg/NKYgCBP)
- [ ] Consider providing a dump file using b2World::Dump
